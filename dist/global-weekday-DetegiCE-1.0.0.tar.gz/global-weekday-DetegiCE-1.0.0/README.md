# Global Weekday

Convert date to weekday in global languages!